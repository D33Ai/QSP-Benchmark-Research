# QSP hidden parity technical review materials

Kellar A. Moore and Troy Hamner, D33 AI. Review preprint v1.0, November 25, 2026.

Open the accompanying paper or read hidden_parity/manuscript.md. To run the
checks, use the six commands in Appendix B from the root of this unzipped
folder. The replay requires Python 3.10+ and, for the optional SAT cross-check,
the Z3 shared library. The recorded replay used Python 3.12.14 and Z3 4.13.3.
Verify the archive contents with: sha256sum -c SHA256SUMS
